<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class auth extends CI_Controller {

	public function index(){
		$this->load->view('login');
	}


	public function registration(){
		$nama = $this->input->post('username');
		$pass =  $this->input->post('pwd') ;
		$role = $this->input->post('role') ;

		$this->db->insert('user' , ['username' => $nama , 'passw' => $pass , 'role' => $role ]) ;

		redirect('index.php/auth');
	}

	public function loginProcess(){
		$username = $this->input->post('username');
		$pass =  $this->input->post('pwd') ;
		$data = $this->db->get_where('user', ['username' => $username , "passw" => $pass]);
		
		$userdata ;
		$userrole ;
		foreach ($data->result() as $nilai) {
			# code...
			$userdata = $nilai->username ;
			$userrole = $nilai->role;

		}

		$this->session->set_userdata('role',$userrole);
		$this->session->set_userdata('username',$userdata);

		redirect('index.php/auth/show');
	}
	public function register(){
		$this->load->view('register');

	}

	public function show(){
		$session = $this->session->userdata('username') ;
		if($session != null ){
			$data['data'] = $this->db->query('select * from artikel1') ;

		$this->load->view('view' , $data);
		
		}else{
			redirect('index.php/auth');
		}

		

	}

	public function hapus($nilai){
		
		$data = $this->db->get_where('artikel1', ['id' => $nilai]) ;
		$userrole ;
		foreach ($data->result() as $row) {
			# code...
			$userrole = $row->role;

		}

		$session = $this->session->userdata('role');
		if($userrole == "admin"){
			$this->db->delete('artikel1', array('id' => $nilai) );
			redirect('index.php/auth/show');
		}else if($userrole != $session ){
			echo "Maaf tidak dapat dihapus ";
			redirect('index.php/auth/show');
		}else{
			
			$this->db->delete('artikel1', array('id' => $nilai) );
		
			redirect('index.php/auth/show');
		}
	}

	public function data(){
			$session = $this->session->userdata('role');
		if($session == "admin"){
		$this->load->view('tambah');
	}else{
		redirect('index.php/auth/show');
	}
	}

	public function tambahData(){
	
		$data = $this->input->post('deskripsi') ;
		$data2 = $this->input->post('role') ;

		$this->db->insert('artikel1' , ['deskripsi' => $data , 'role' => $data2]) ;

		redirect('index.php/auth/show');
	}
	

	public function update($nilai){
			$session = $this->session->userdata('role');
		if($session == "admin"){
		$data['nilai'] = $nilai ;
		$this->load->view('update', $data);
	}else{
		redirect('index.php/auth/show');
	}
		
	}

	public function updateData(){

		$data = $this->input->post('deskripsi');
		$nilai = $this->input->post('nilai');
			$role = $this->input->post('role') ;

		$this->db->replace('artikel1' , ['id' => $nilai , 'deskripsi' => $data , 'role' => $role]) ;

		redirect('index.php/auth/show');	
	}

	public function logout(){
		 $this->session->unset_userdata('username');
		
		$this->session->unset_userdata('role');

	redirect('index.php/auth/');	
	}


}